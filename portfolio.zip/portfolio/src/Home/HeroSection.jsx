import React from 'react';
import { FaArrowRight } from 'react-icons/fa';

const HeroSection = () => {
    return (
        <div className='max-w-[1000px] mx-auto py-24  flex flex-col justify-center h-full'>

            <p className='text-pink-600'>Hi, my name is</p>
            <h1 className='text-4xl sm:text-7xl font-bold text-white'>Md.Jewel Rana</h1>
            <h1 className='text-4xl sm:text-7xl font-bold text-[#8892b0]'>I am a MERN Stack Developer</h1>
            <p className='text-[#8892b0] py-4 max-w-[700px]'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam alias a consequuntur perferendis natus sapiente vero explicabo sequi aliquid quasi? Aspernatur, reiciendis debitis quam nulla distinctio, praesentium, eligendi sit illo beatae sequi voluptates qui voluptate culpa at nihil ducimus harum!</p>


            <div>
                <button className="btn btn-outline btn-success group">View Work <FaArrowRight className='group-hover:rotate-90 duration-300 text-2xl ml-4'></FaArrowRight></button>
            </div>



        </div>
    );
};

export default HeroSection;