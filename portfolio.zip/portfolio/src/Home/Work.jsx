import React from 'react';
import { Link } from 'react-router-dom';
import Photo from '../../public/logo1.png'

const Work = () => {
    return (
        <div name='skills' className=' text-gray-300 w-full  '>
            <div className='max-w-[1000px] mx-auto p-4 flex flex-col justify-center w-full h-full'>
                <div>
                    <p className='text-4xl  py-4 inline font-bold border-b-4 border-pink-600  '>Work</p>
                    <p className='py-12'>Check out some of my recent work.</p>
                </div>


                {/* container  */}
                <div className='w-full  grid  md:grid-cols-2 lg:grid-cols-3 gap-4 text-center py-8'>


                    {/* child */}
                    <div style={{ backgroundImage: `url(${Photo})` }} className='shadow-lg shadow-[#040c16]  duration-500 group container rounded-md flex justify-center items-center mx-auto content-div'>

                        <div className='opacity-0  group-hover:opacity-100'>
                            <span className='text-2xl font-bold text-white tracking-wider'>
                                React JS application
                            </span>
                            <div className='pt-8 text-center'>
                                <Link> <button className="btn btn-warning text-white">Demo</button></Link>
                                <Link> <button className="btn btn-warning text-white">Code</button></Link>
                            </div>
                        </div>
                    </div>
                    <div style={{ backgroundImage: `url(${Photo})` }} className='shadow-lg shadow-[#040c16]  duration-500 group container rounded-md flex justify-center items-center mx-auto content-div'>

                        <div className='opacity-0  group-hover:opacity-100'>
                            <span className='text-2xl font-bold text-white tracking-wider'>
                                React JS application
                            </span>
                            <div className='pt-8 text-center'>
                                <Link> <button className="btn btn-warning text-white">Demo</button></Link>
                                <Link> <button className="btn btn-warning text-white">Code</button></Link>
                            </div>
                        </div>
                    </div>
                    <div style={{ backgroundImage: `url(${Photo})` }} className='shadow-lg shadow-[#040c16]  duration-500 group container rounded-md flex justify-center items-center mx-auto content-div'>

                        <div className='opacity-0  group-hover:opacity-100'>
                            <span className='text-2xl font-bold text-white tracking-wider'>
                                React JS application
                            </span>
                            <div className='pt-8 text-center'>
                                <Link> <button className="btn btn-warning text-white">Demo</button></Link>
                                <Link> <button className="btn btn-warning text-white">Code</button></Link>
                            </div>
                        </div>
                    </div>
                    <div style={{ backgroundImage: `url(${Photo})` }} className='shadow-lg shadow-[#040c16]  duration-500 group container rounded-md flex justify-center items-center mx-auto content-div'>

                        <div className='opacity-0  group-hover:opacity-100'>
                            <span className='text-2xl font-bold text-white tracking-wider'>
                                React JS application
                            </span>
                            <div className='pt-8 text-center'>
                                <Link> <button className="btn btn-warning text-white">Demo</button></Link>
                                <Link> <button className="btn btn-warning text-white">Code</button></Link>
                            </div>
                        </div>
                    </div>
                    <div style={{ backgroundImage: `url(${Photo})` }} className='shadow-lg shadow-[#040c16]  duration-500 group container rounded-md flex justify-center items-center mx-auto content-div'>

                        <div className='opacity-0  group-hover:opacity-100'>
                            <span className='text-2xl font-bold text-white tracking-wider'>
                                React JS application
                            </span>
                            <div className='pt-8 text-center'>
                                <Link> <button className="btn btn-warning text-white">Demo</button></Link>
                                <Link> <button className="btn btn-warning text-white">Code</button></Link>
                            </div>
                        </div>
                    </div>
                    <div style={{ backgroundImage: `url(${Photo})` }} className='shadow-lg shadow-[#040c16]  duration-500 group container rounded-md flex justify-center items-center mx-auto content-div'>

                        <div className='opacity-0  group-hover:opacity-100'>
                            <span className='text-2xl font-bold text-white tracking-wider'>
                                React JS application
                            </span>
                            <div className='pt-8 text-center'>
                                <Link> <button className="btn btn-warning text-white">Demo</button></Link>
                                <Link> <button className="btn btn-warning text-white">Code</button></Link>
                            </div>
                        </div>
                    </div>
                    <div style={{ backgroundImage: `url(${Photo})` }} className='shadow-lg shadow-[#040c16]  duration-500 group container rounded-md flex justify-center items-center mx-auto content-div'>

                        <div className='opacity-0  group-hover:opacity-100'>
                            <span className='text-2xl font-bold text-white tracking-wider'>
                                React JS application
                            </span>
                            <div className='pt-8 text-center'>
                                <Link> <button className="btn btn-warning text-white">Demo</button></Link>
                                <Link> <button className="btn btn-warning text-white">Code</button></Link>
                            </div>
                        </div>
                    </div>






                </div>






            </div>



        </div>
    );
};

export default Work;